import React, { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import "./Navigation.css";

const Navigation = () => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const [user, setUser] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 50);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  // Try to read stored user info or decode token to get user name
  useEffect(() => {
    const stored =
      localStorage.getItem("user") || localStorage.getItem("userInfo");
    if (stored) {
      try {
        setUser(JSON.parse(stored));
        return;
      } catch {}
    }

    const token = localStorage.getItem("userToken");
    const userInfo = localStorage.getItem("userInfo");

    if (userInfo) {
      try {
        const parsed = JSON.parse(userInfo);
        setUser({ name: parsed.name || parsed.email || "User" });
        return;
      } catch (err) {
        console.error("Error parsing user info:", err);
      }
    }

    if (token) {
      try {
        const payload = decodeToken(token);
        if (payload) {
          // Use email if name is not available, or fallback to "User"
          const displayName =
            payload.name || payload.email?.split("@")[0] || "User";
          setUser({ name: displayName });
          return;
        }
      } catch (err) {
        console.error("Error decoding token:", err);
      }
    }

    setUser(null);
  }, []);

  const decodeToken = (token) => {
    if (!token) return null;
    try {
      const b64 = token.split(".")[1];
      const base64 = b64.replace(/-/g, "+").replace(/_/g, "/");
      const json = decodeURIComponent(
        atob(base64)
          .split("")
          .map((c) => "%" + ("00" + c.charCodeAt(0).toString(16)).slice(-2))
          .join("")
      );
      return JSON.parse(json);
    } catch {
      return null;
    }
  };

  const handleLogout = () => {
    localStorage.removeItem("userToken");
    localStorage.removeItem("user");
    localStorage.removeItem("userInfo");
    setUser(null);
    navigate("/login");
  };

  const navLinks = [
    { name: "Home", path: "/" },
    { name: "Destinations", path: "/destinations" },
    { name: "Packages", path: "/packages" },
    { name: "Gallery", path: "/gallery" },
    { name: "Blog", path: "/blog" },
    { name: "About", path: "/about" },
    { name: "Booking", path: "/booking" },
  ];

  const handleRegisterClick = () => navigate("/register");

  return (
    <nav className={`navbar ${isScrolled ? "scrolled" : ""}`}>
      <div className="nav-container">
        <div className="nav-logo">
          <Link to="/">
            <h2>TravelEase</h2>
          </Link>
        </div>

        <ul className={`nav-menu ${isMobileMenuOpen ? "active" : ""}`}>
          {navLinks.map((link) => (
            <li key={link.name} className="nav-item">
              <Link to={link.path} onClick={() => setIsMobileMenuOpen(false)}>
                {link.name}
              </Link>
            </li>
          ))}

          <li className="nav-item auth-btns">
            {user ? (
              <>
                <span className="user-name d-flex justify-content-center align-items-center">Hello, {user.name}</span>
                <button className="register-btn" onClick={handleLogout}>
                  Logout
                </button>
              </>
            ) : (
              <>
                <Link to="/login">
                  <button className="login-btn">Login</button>
                </Link>
                <button className="register-btn" onClick={handleRegisterClick}>
                  Register
                </button>
              </>
            )}
          </li>
        </ul>

        <button
          className={`mobile-menu-btn ${isMobileMenuOpen ? "active" : ""}`}
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          aria-label="Toggle menu"
        >
          <span></span>
          <span></span>
          <span></span>
        </button>
      </div>
    </nav>
  );
};

export default Navigation;
