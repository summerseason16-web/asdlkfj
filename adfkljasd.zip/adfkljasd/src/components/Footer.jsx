import React from 'react';
import './Footer.css';

const Footer = () => {
    return (
        <footer className="footer">
            <div className="container">
                <div className="footer-content">
                    {/* Footer Top Section */}
                    <div className="footer-top">
                        <div className="footer-brand">
                            <h3>TravelExplorer</h3>
                            <p>Discover the world's hidden treasures with us. Your journey begins here.</p>
                            <div className="social-links">
                                <a href="#" className="social-link">📘</a>
                                <a href="#" className="social-link">📷</a>
                                <a href="#" className="social-link">🐦</a>
                                <a href="#" className="social-link">💼</a>
                            </div>
                        </div>
                        
                        <div className="footer-links">
                            <div className="footer-column">
                                <h4>Destinations</h4>
                                <ul>
                                    <li><a href="#">Europe</a></li>
                                    <li><a href="#">Asia</a></li>
                                    <li><a href="#">North America</a></li>
                                    <li><a href="#">South America</a></li>
                                    <li><a href="#">Africa</a></li>
                                </ul>
                            </div>
                            
                            <div className="footer-column">
                                <h4>Company</h4>
                                <ul>
                                    <li><a href="#">About Us</a></li>
                                    <li><a href="#">Careers</a></li>
                                    <li><a href="#">Blog</a></li>
                                    <li><a href="#">Press</a></li>
                                    <li><a href="#">Gift Cards</a></li>
                                </ul>
                            </div>
                            
                            <div className="footer-column">
                                <h4>Support</h4>
                                <ul>
                                    <li><a href="#">Contact</a></li>
                                    <li><a href="#">FAQ</a></li>
                                    <li><a href="#">Booking Info</a></li>
                                    <li><a href="#">Privacy Policy</a></li>
                                    <li><a href="#">Terms of Service</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    
                    {/* Footer Bottom Section */}
                    <div className="footer-bottom">
                        <div className="footer-bottom-content">
                            <p>&copy; 2024 TravelExplorer. All rights reserved.</p>
                            <div className="footer-bottom-links">
                                <a href="#">Privacy</a>
                                <a href="#">Terms</a>
                                <a href="#">Sitemap</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
    );
};

export default Footer;