const API = import.meta.env.VITE_API_URL || "http://localhost:5000";

export async function fetchPackages() {
  const res = await fetch(`${API}/api/packages`);
  if (!res.ok) throw new Error("Failed to fetch packages");
  return res.json();
}

export async function fetchPackageById(id) {
  const res = await fetch(`${API}/api/packages/${id}`);
  if (!res.ok) throw new Error("Failed to fetch package");
  return res.json();
}

export async function calculatePrice(packageId, numberOfPeople, startDate) {
  const res = await fetch(`${API}/api/packages/calculate-price`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ packageId, numberOfPeople, startDate }),
  });
  if (!res.ok) throw new Error("Price calc failed");
  return res.json();
}
