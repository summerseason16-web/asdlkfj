const API = import.meta.env.VITE_API_URL || "http://localhost:5000";

export async function calculatePrice(packageId, numberOfPeople) {
  const res = await fetch(`${API}/api/packages/calculate-price`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ packageId, numberOfPeople }),
  });
  if (!res.ok) throw new Error((await res.json()).message || "Price calc failed");
  return res.json();
}

export async function createBooking(payload) {
  const token = localStorage.getItem("userToken");
  if (!token) throw new Error("Not authenticated");
  const res = await fetch(`${API}/api/bookings`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`,
    },
    body: JSON.stringify(payload),
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.message || "Booking failed");
  return data;
}

export async function getMyBookings() {
  const token = localStorage.getItem("userToken");
  if (!token) throw new Error("Not authenticated");
  const res = await fetch(`${API}/api/bookings/my-bookings`, {
    headers: { Authorization: `Bearer ${token}` },
  });
  if (!res.ok) throw new Error((await res.json()).message || "Fetch failed");
  return res.json();
}