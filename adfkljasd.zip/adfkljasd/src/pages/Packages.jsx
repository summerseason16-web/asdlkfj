// Packages.jsx
import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { fetchPackages } from "../api/packages";
import "./Packages.css";

const Packages = () => {
  const [packages, setPackages] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedDuration, setSelectedDuration] = useState("all");
  const [selectedDestination, setSelectedDestination] = useState("all");
  const [priceRange, setPriceRange] = useState([0, 5000]);
  const [expandedItinerary, setExpandedItinerary] = useState(null);

  useEffect(() => {
    fetchPackages()
      .then((data) => setPackages(data))
      .catch((err) => console.error(err))
      .finally(() => setLoading(false));
  }, []);

  const durations = [
    "All",
    "1 Day",
    "2 Days",
    "3 Days",
    "4 Days",
    "5 Days",
    "6 Days",
    "7 Days+",
  ];
  const destinations = [
    "All",
    "Nepal",
    "Indonesia",
    "Maldives",
    "Thailand",
    "UAE",
  ];
  const categories = ["All", "Adventure", "Cultural", "Luxury", "Relaxation"];

  const filteredPackages = packages
    .filter(
      (pkg) => selectedDuration === "all" || pkg.duration === selectedDuration
    )
    .filter(
      (pkg) =>
        selectedDestination === "all" || pkg.destination === selectedDestination
    )
    .filter(
      (pkg) =>
        pkg.price.perPerson >= priceRange[0] &&
        pkg.price.perPerson <= priceRange[1]
    );

  if (loading) return <div>Loading...</div>;

  return (
    <div className="packages-page">
      {/* Hero Section */}
      <section className="packages-hero">
        <div className="container">
          <div className="hero-content">
            <h1 className="hero-title">Travel Packages</h1>
            <p className="hero-subtitle">
              Discover perfectly curated travel experiences with detailed
              itineraries, premium accommodations, and unforgettable adventures
            </p>
          </div>
        </div>
      </section>

      {/* Filters Section */}
      <section className="filters-section">
        <div className="container">
          <div className="filters-grid">
            {/* Duration Filter */}
            <div className="filter-group">
              <label className="filter-label">Duration</label>
              <div className="filter-options">
                {durations.map((duration) => (
                  <button
                    key={duration}
                    className={`filter-btn ${
                      selectedDuration ===
                      (duration === "All" ? "all" : duration)
                        ? "active"
                        : ""
                    }`}
                    onClick={() =>
                      setSelectedDuration(duration === "All" ? "all" : duration)
                    }
                  >
                    {duration}
                  </button>
                ))}
              </div>
            </div>

            {/* Destination Filter */}
            <div className="filter-group">
              <label className="filter-label">Destination</label>
              <div className="filter-options">
                {destinations.map((destination) => (
                  <button
                    key={destination}
                    className={`filter-btn ${
                      selectedDestination ===
                      (destination === "All" ? "all" : destination)
                        ? "active"
                        : ""
                    }`}
                    onClick={() =>
                      setSelectedDestination(
                        destination === "All" ? "all" : destination
                      )
                    }
                  >
                    {destination}
                  </button>
                ))}
              </div>
            </div>

            {/* Price Range */}
            <div className="filter-group">
              <label className="filter-label">
                Price Range: ${priceRange[0]} - ${priceRange[1]}
              </label>
              <input
                type="range"
                min="0"
                max="5000"
                step="100"
                value={priceRange[1]}
                onChange={(e) =>
                  setPriceRange([priceRange[0], parseInt(e.target.value)])
                }
                className="price-slider"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Packages Grid */}
      <section className="packages-section">
        <div className="container">
          <div className="packages-grid">
            {filteredPackages.map((pkg) => (
              <div key={pkg.id} className="package-card">
                {/* Featured Badge */}
                {pkg.featured && <div className="featured-badge">Featured</div>}

                {/* Package Image */}
                <div className="package-image">
                  <img src={pkg.image} alt={pkg.title} />
                  <div className="package-overlay">
                    <span className="category-badge">{pkg.category}</span>
                    <div className="rating-badge">
                      <span className="stars">★★★★★</span>
                      <span className="rating">{pkg.rating}</span>
                    </div>
                  </div>
                </div>

                {/* Package Content */}
                <div className="package-content">
                  {/* Header */}
                  <div className="package-header">
                    <div>
                      <h3 className="package-title">{pkg.title}</h3>
                      <div className="package-meta">
                        <span className="destination">{pkg.destination}</span>
                        <span className="duration">{pkg.duration}</span>
                        <span className="reviews">{pkg.reviews} reviews</span>
                      </div>
                    </div>
                  </div>

                  {/* Description */}
                  <p className="package-description">
                    A curated experience for {pkg.destination}. Duration:{" "}
                    {pkg.duration}.
                  </p>

                  {/* Footer / Actions */}
                  <div className="package-footer">
                    <div className="price">From ${pkg.price.perPerson}</div>
                    <div className="actions">
                      <Link to={`/package/${pkg.id}`} className="details-btn">
                        Details
                      </Link>
                      <button className="book-btn">Book Now</button>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default Packages;
