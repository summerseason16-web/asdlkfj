import React from 'react';
import './Blog.css';

const Blog = () => {
  const blogPosts = [
    {
      id: 1,
      title: "Top 10 Hidden Gems in Europe You Must Visit",
      excerpt: "Discover the most beautiful and less crowded destinations in Europe that will take your breath away...",
      author: "Sarah Johnson",
      date: "Oct 12, 2024",
      readTime: "5 min read",
      category: "Travel Tips",
      image: "https://images.unsplash.com/photo-1469474968028-56623f02e42e?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80"
    },
    {
      id: 2,
      title: "Sustainable Tourism: How to Travel Responsibly",
      excerpt: "Learn how to make your travels more eco-friendly and support local communities while exploring the world...",
      author: "Mike Chen",
      date: "Oct 10, 2024",
      readTime: "7 min read",
      category: "Sustainability",
      image: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80"
    },
    {
      id: 3,
      title: "The Ultimate Packing Guide for Digital Nomads",
      excerpt: "Everything you need to know about packing smart and working efficiently while traveling the world...",
      author: "Emma Davis",
      date: "Oct 8, 2024",
      readTime: "6 min read",
      category: "Digital Nomad",
      image: "https://images.unsplash.com/photo-1484807352052-23338990c6c6?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80"
    },
    {
      id: 4,
      title: "Cultural Etiquette: Do's and Don'ts Around the World",
      excerpt: "Avoid cultural faux pas and show respect when visiting different countries with this comprehensive guide...",
      author: "Alex Rodriguez",
      date: "Oct 5, 2024",
      readTime: "8 min read",
      category: "Culture",
      image: "https://images.unsplash.com/photo-1552733407-5d5c46c3bb3b?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80"
    },
    {
      id: 5,
      title: "Budget Travel: How to See the World Without Breaking the Bank",
      excerpt: "Smart strategies and tips to travel more while spending less. Your dream trip is more affordable than you think...",
      author: "Lisa Wang",
      date: "Oct 3, 2024",
      readTime: "4 min read",
      category: "Budget Travel",
      image: "https://images.unsplash.com/photo-1488646953014-85cb44e25828?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80"
    },
    {
      id: 6,
      title: "Adventure Travel: Pushing Your Limits Safely",
      excerpt: "From mountain climbing to deep sea diving, learn how to embrace adventure while staying safe...",
      author: "Tom Wilson",
      date: "Oct 1, 2024",
      readTime: "9 min read",
      category: "Adventure",
      image: "https://images.unsplash.com/photo-1464822759849-e41f5bc7c13f?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80"
    }
  ];

  const categories = ["All", "Travel Tips", "Sustainability", "Digital Nomad", "Culture", "Budget Travel", "Adventure"];

  return (
    <div className="blog-page">
      {/* Hero Section */}
      <section className="blog-hero">
        <div className="container">
          <div className="hero-content">
            <h1 className="hero-title">Travel Blog</h1>
            <p className="hero-subtitle">
              Discover inspiring stories, travel tips, and expert advice from around the world
            </p>
            <div className="search-box">
              <input 
                type="text" 
                placeholder="Search articles..."
                className="search-input"
              />
              <button className="search-btn">
                <svg className="search-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                </svg>
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Categories */}
      <section className="blog-categories">
        <div className="container">
          <div className="categories-list">
            {categories.map((category, index) => (
              <button 
                key={index} 
                className={`category-btn ${index === 0 ? 'active' : ''}`}
              >
                {category}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Blog Posts Grid */}
      <section className="blog-posts-section">
        <div className="container">
          <div className="posts-grid">
            {blogPosts.map((post) => (
              <article key={post.id} className="blog-card">
                <div className="blog-image">
                  <img src={post.image} alt={post.title} />
                  <div className="category-tag">{post.category}</div>
                </div>
                
                <div className="blog-content">
                  <div className="post-meta">
                    <span className="author">{post.author}</span>
                    <span className="dot">•</span>
                    <span className="date">{post.date}</span>
                    <span className="dot">•</span>
                    <span className="read-time">{post.readTime}</span>
                  </div>
                  
                  <h3 className="post-title">{post.title}</h3>
                  <p className="post-excerpt">{post.excerpt}</p>
                  
                  <button className="read-more-btn">
                    Read More
                    <svg className="arrow-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 5l7 7m0 0l-7 7m7-7H3" />
                    </svg>
                  </button>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default Blog;