
import React from 'react';
import './About.css';

const About = () => {
  const teamMembers = [
    {
      id: 1,
      name: "Sarah Johnson",
      role: "Founder & CEO",
      bio: "Passionate traveler with 10+ years of experience exploring 50+ countries",
      image: "https://images.unsplash.com/photo-1494790108755-2616b612b786?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80"
    },
    {
      id: 2,
      name: "Mike Chen",
      role: "Travel Expert",
      bio: "Adventure seeker and cultural enthusiast specializing in Asian destinations",
      image: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80"
    },
    {
      id: 3,
      name: "Emma Davis",
      role: "Content Director",
      bio: "Storyteller and photographer capturing the essence of every destination",
      image: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80"
    },
    {
      id: 4,
      name: "Alex Rodriguez",
      role: "Customer Experience",
      bio: "Dedicated to making every journey memorable and hassle-free",
      image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80"
    }
  ];

  const stats = [
    { number: "50K+", label: "Happy Travelers" },
    { number: "100+", label: "Destinations" },
    { number: "15+", label: "Years Experience" },
    { number: "24/7", label: "Customer Support" }
  ];

  const values = [
    {
      icon: "🌍",
      title: "Global Perspective",
      description: "We believe in connecting people across cultures and borders through meaningful travel experiences."
    },
    {
      icon: "💚",
      title: "Sustainable Travel",
      description: "Committed to responsible tourism that benefits local communities and preserves natural environments."
    },
    {
      icon: "⭐",
      title: "Excellence",
      description: "Dedicated to providing exceptional service and creating unforgettable memories for every traveler."
    },
    {
      icon: "🤝",
      title: "Trust & Transparency",
      description: "Building lasting relationships based on honesty, reliability, and open communication."
    }
  ];

  return (
    <div className="about-page">
      {/* Hero Section */}
      <section className="about-hero">
        <div className="container">
          <div className="hero-content">
            <h1 className="hero-title">About Wanderlust</h1>
            <p className="hero-subtitle">
              We're passionate about creating unforgettable travel experiences that connect people with the world's most amazing destinations
            </p>
          </div>
        </div>
      </section>

      {/* Mission Section */}
      <section className="mission-section">
        <div className="container">
          <div className="mission-content">
            <div className="mission-text">
              <h2>Our Story</h2>
              <p>
                Founded in 2010, Wanderlust began as a small team of travel enthusiasts with a big dream: 
                to make world-class travel experiences accessible to everyone. What started as a passion project 
                has grown into a trusted platform helping thousands of travelers discover their perfect getaway.
              </p>
              <p>
                We believe that travel has the power to transform lives, broaden perspectives, and create 
                lasting memories. Our mission is to curate exceptional journeys that combine adventure, 
                comfort, and authentic cultural experiences.
              </p>
            </div>
            <div className="mission-image">
              <img 
                src="https://images.unsplash.com/photo-1522202176988-66273c2fd55f?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80" 
                alt="Our team" 
              />
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="stats-section">
        <div className="container">
          <div className="stats-grid">
            {stats.map((stat, index) => (
              <div key={index} className="stat-item">
                <div className="stat-number">{stat.number}</div>
                <div className="stat-label">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Values Section */}
      <section className="values-section">
        <div className="container">
          <h2 className="section-title">Our Values</h2>
          <div className="values-grid">
            {values.map((value, index) => (
              <div key={index} className="value-card">
                <div className="value-icon">{value.icon}</div>
                <h3 className="value-title">{value.title}</h3>
                <p className="value-description">{value.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Team Section */}
      <section className="team-section">
        <div className="container">
          <h2 className="section-title">Meet Our Team</h2>
          <p className="section-subtitle">
            Passionate travelers and experts dedicated to making your journey extraordinary
          </p>
          <div className="team-grid">
            {teamMembers.map((member) => (
              <div key={member.id} className="team-card">
                <div className="member-image">
                  <img src={member.image} alt={member.name} />
                </div>
                <div className="member-info">
                  <h3 className="member-name">{member.name}</h3>
                  <p className="member-role">{member.role}</p>
                  <p className="member-bio">{member.bio}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default About;