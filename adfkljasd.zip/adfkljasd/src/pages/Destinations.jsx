import React, { useState, useEffect } from "react";
import "./DestinationPage.css";

const Destinations = () => {
  const [destinations, setDestinations] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState("All");

  useEffect(() => {
    fetchDestinations();
  }, [search, filter]);

  const fetchDestinations = async () => {
    try {
      const params = new URLSearchParams();
      if (search) params.append("search", search);
      if (filter !== "All") params.append("category", filter);

      const response = await fetch(`/api/destinations?${params}`);
      const data = await response.json();
      setDestinations(data);
    } catch (error) {
      console.error("Error fetching destinations:", error);
    } finally {
      setLoading(false);
    }
  };

  const renderStars = (rating) => {
    const stars = [];
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 !== 0;

    for (let i = 0; i < fullStars; i++) {
      stars.push(
        <span key={i} className="star full">
          ★
        </span>
      );
    }

    if (hasHalfStar) {
      stars.push(
        <span key="half" className="star half">
          ★
        </span>
      );
    }

    const emptyStars = 5 - stars.length;
    for (let i = 0; i < emptyStars; i++) {
      stars.push(
        <span key={`empty-${i}`} className="star empty">
          ★
        </span>
      );
    }

    return stars;
  };

  return (
    <div className="destination-page">
      {/* Header Section */}
      <section className="destination-header">
        <div className="container">
          <div className="header-content">
            <h1 className="page-title">Popular Destinations</h1>
            <p className="page-subtitle">
              Discover amazing places around the world. From bustling cities to
              serene beaches, find your perfect getaway.
            </p>

            {/* Search and Filters */}
            <div className="filters-section-d">
              <div className="search-container">
                <div className="search-box">
                  <input
                    type="text"
                    placeholder="Search destinations..."
                    className="search-input"
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                  />
                </div>

                <div className="filter-buttons">
                  <button
                    className={`filter-btn ${filter === "All" ? "active" : ""}`}
                    onClick={() => setFilter("All")}
                  >
                    All Regions
                  </button>
                  <button
                    className={`filter-btn ${
                      filter === "All Categories" ? "active" : ""
                    }`}
                    onClick={() => setFilter("All Categories")}
                  >
                    All Categories
                  </button>
                  <button
                    className={`filter-btn ${
                      filter === "Most Popular" ? "active" : ""
                    }`}
                    onClick={() => setFilter("Most Popular")}
                  >
                    Most Popular
                  </button>
                  <button
                    className={`filter-btn ${
                      filter === "Trending" ? "active" : ""
                    }`}
                    onClick={() => setFilter("Trending")}
                  >
                    Trending
                  </button>
                </div>
              </div>
            </div>

            <div className="results-info">
              <span className="results-count">
                Showing {destinations.length} of {destinations.length}{" "}
                destinations
              </span>
            </div>
          </div>
        </div>
      </section>

      {/* Destinations Grid */}
      <div className="destination-container">
        {destinations.map((destination) => (
          <div className="destination-card" key={destination.id}>
            <div className="destination-image">
              <img src={destination.image} alt={destination.name} />
              <span
                className={`tag ${
                  destination.category === "MOST POPULAR"
                    ? "popular"
                    : "trending"
                }`}
              >
                {destination.category}
              </span>
              <span className="rating">⭐ {destination.rating}</span>
            </div>
            <div className="destination-content">
              <div className="d-flex justify-content-between">
                <h3 className="destination-name">{destination.name}</h3>
                <p className="destination-price">From {destination.price}</p>
              </div>
              <p className="destination-description">
                {destination.description}
              </p>
              <button className="explore-btn">
                <span>Explore Details</span>
                <svg
                  className="btn-arrow"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M14 5l7 7m0 0l-7 7m7-7H3"
                  />
                </svg>
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Destinations;
