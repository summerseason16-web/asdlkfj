// Booking.jsx
import React, { useState } from 'react';
import './Booking.css';

const Booking = () => {
  const [bookingStep, setBookingStep] = useState(1);
  const [formData, setFormData] = useState({
    package: '',
    travelers: 1,
    travelDate: '',
    name: '',
    email: '',
    phone: '',
    specialRequests: ''
  });

  const popularPackages = [
    {
      id: 1,
      title: "Kathmandu Valley Explorer",
      destination: "Nepal",
      duration: "1 Day",
      price: 89,
      image: "https://images.unsplash.com/photo-1544735716-2f8e3f4c3b3c?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80"
    },
    {
      id: 2,
      title: "Shey Phoksundo Lake Trek",
      destination: "Nepal",
      duration: "7 Days",
      price: 899,
      image: "https://images.unsplash.com/photo-1583454110551-21f2fa2ef61b?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80"
    },
    {
      id: 3,
      title: "Bali Cultural Retreat",
      destination: "Indonesia",
      duration: "5 Days",
      price: 599,
      image: "https://images.unsplash.com/photo-1518548419970-58e3b4079ab2?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80"
    },
    {
      id: 4,
      title: "Maldives Paradise Escape",
      destination: "Maldives",
      duration: "4 Days",
      price: 1299,
      image: "https://images.unsplash.com/photo-1514282401047-d79a71a590e8?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80"
    }
  ];

  const handleInputChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handlePackageSelect = (packageTitle) => {
    setFormData({
      ...formData,
      package: packageTitle
    });
    setBookingStep(2);
  };

  const calculateTotal = () => {
    const selectedPackage = popularPackages.find(pkg => pkg.title === formData.package);
    return selectedPackage ? selectedPackage.price * formData.travelers : 0;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setBookingStep(3);
    // Here you would typically send the booking data to your backend
    console.log('Booking submitted:', formData);
  };

  return (
    <div className="booking-page">
      {/* Hero Section */}
      <section className="booking-hero">
        <div className="container">
          <div className="hero-content">
            <h1 className="hero-title">Book Your Adventure</h1>
            <p className="hero-subtitle">
              Secure your dream vacation with our easy booking process. 
              Get ready for unforgettable experiences!
            </p>
          </div>
        </div>
      </section>

      {/* Booking Process */}
      <section className="booking-process">
        <div className="container">
          <div className="progress-steps">
            <div className={`step ${bookingStep >= 1 ? 'active' : ''}`}>
              <div className="step-number">1</div>
              <span className="step-label">Choose Package</span>
            </div>
            <div className={`step ${bookingStep >= 2 ? 'active' : ''}`}>
              <div className="step-number">2</div>
              <span className="step-label">Your Details</span>
            </div>
            <div className={`step ${bookingStep >= 3 ? 'active' : ''}`}>
              <div className="step-number">3</div>
              <span className="step-label">Confirmation</span>
            </div>
          </div>

          {/* Package Selection */}
          {bookingStep === 1 && (
            <div className="booking-step">
              <h2 className="step-title">Select Your Package</h2>
              <div className="packages-grid">
                {popularPackages.map(pkg => (
                  <div 
                    key={pkg.id} 
                    className={`package-card ${formData.package === pkg.title ? 'selected' : ''}`}
                    onClick={() => handlePackageSelect(pkg.title)}
                  >
                    <div className="package-image">
                      <img src={pkg.image} alt={pkg.title} />
                    </div>
                    <div className="package-info">
                      <h3 className="package-name">{pkg.title}</h3>
                      <p className="package-destination">{pkg.destination}</p>
                      <p className="package-duration">{pkg.duration}</p>
                      <div className="package-price">${pkg.price}/person</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/*  Booking Form */}
          {bookingStep === 2 && (
            <div className="booking-step">
              <h2 className="step-title">Your Booking Details</h2>
              <div className="booking-form-container">
                <form onSubmit={handleSubmit} className="booking-form">
                  <div className="form-grid">
                    <div className="form-group">
                      <label className="form-label">Selected Package</label>
                      <div className="selected-package">
                        {formData.package}
                      </div>
                    </div>

                    <div className="form-group">
                      <label className="form-label">Number of Travelers</label>
                      <select 
                        name="travelers"
                        value={formData.travelers}
                        onChange={handleInputChange}
                        className="form-input"
                      >
                        {[1,2,3,4,5,6,7,8,9,10].map(num => (
                          <option key={num} value={num}>{num} {num === 1 ? 'Person' : 'People'}</option>
                        ))}
                      </select>
                    </div>

                    <div className="form-group">
                      <label className="form-label">Travel Date</label>
                      <input
                        type="date"
                        name="travelDate"
                        value={formData.travelDate}
                        onChange={handleInputChange}
                        className="form-input"
                        required
                      />
                    </div>

                    <div className="form-group">
                      <label className="form-label">Full Name</label>
                      <input
                        type="text"
                        name="name"
                        value={formData.name}
                        onChange={handleInputChange}
                        className="form-input"
                        placeholder="Enter your full name"
                        required
                      />
                    </div>

                    <div className="form-group">
                      <label className="form-label">Email Address</label>
                      <input
                        type="email"
                        name="email"
                        value={formData.email}
                        onChange={handleInputChange}
                        className="form-input"
                        placeholder="Enter your email"
                        required
                      />
                    </div>

                    <div className="form-group">
                      <label className="form-label">Phone Number</label>
                      <input
                        type="tel"
                        name="phone"
                        value={formData.phone}
                        onChange={handleInputChange}
                        className="form-input"
                        placeholder="Enter your phone number"
                        required
                      />
                    </div>

                    <div className="form-group full-width">
                      <label className="form-label">Special Requests</label>
                      <textarea
                        name="specialRequests"
                        value={formData.specialRequests}
                        onChange={handleInputChange}
                        className="form-textarea"
                        placeholder="Any special requirements or requests..."
                        rows="4"
                      />
                    </div>
                  </div>

                  {/* Price Summary */}
                  <div className="price-summary">
                    <h3 className="summary-title">Booking Summary</h3>
                    <div className="summary-details">
                      <div className="summary-row">
                        <span>Package:</span>
                        <span>{formData.package}</span>
                      </div>
                      <div className="summary-row">
                        <span>Travelers:</span>
                        <span>{formData.travelers}</span>
                      </div>
                      <div className="summary-row">
                        <span>Price per person:</span>
                        <span>${popularPackages.find(pkg => pkg.title === formData.package)?.price || 0}</span>
                      </div>
                      <div className="summary-row total">
                        <span>Total Amount:</span>
                        <span>${calculateTotal()}</span>
                      </div>
                    </div>
                  </div>

                  <div className="form-actions">
                    <button 
                      type="button" 
                      className="btn-secondary"
                      onClick={() => setBookingStep(1)}
                    >
                      Back
                    </button>
                    <button type="submit" className="btn-primary">
                      Confirm Booking
                    </button>
                  </div>
                </form>
              </div>
            </div>
          )}

          {/* Confirmation */}
          {bookingStep === 3 && (
            <div className="booking-step confirmation">
              <div className="confirmation-content">
                <div className="success-icon">✓</div>
                <h2 className="confirmation-title">Booking Confirmed!</h2>
                <p className="confirmation-message">
                  Thank you for booking with us! We've sent a confirmation email to {formData.email}. 
                  Our travel expert will contact you within 24 hours to discuss the details of your adventure.
                </p>
                
                <div className="booking-details">
                  <h3>Booking Details</h3>
                  <div className="details-grid">
                    <div className="detail-item">
                      <strong>Package:</strong> {formData.package}
                    </div>
                    <div className="detail-item">
                      <strong>Travelers:</strong> {formData.travelers}
                    </div>
                    <div className="detail-item">
                      <strong>Travel Date:</strong> {formData.travelDate}
                    </div>
                    <div className="detail-item">
                      <strong>Total Amount:</strong> ${calculateTotal()}
                    </div>
                    <div className="detail-item">
                      <strong>Booking Reference:</strong> TRV-{Math.random().toString(36).substr(2, 9).toUpperCase()}
                    </div>
                  </div>
                </div>

                <div className="confirmation-actions">
                  <button className="btn-primary" onClick={() => window.print()}>
                    Print Confirmation
                  </button>
                  <button 
                    className="btn-secondary"
                    onClick={() => {
                      setBookingStep(1);
                      setFormData({
                        package: '',
                        travelers: 1,
                        travelDate: '',
                        name: '',
                        email: '',
                        phone: '',
                        specialRequests: ''
                      });
                    }}
                  >
                    Book Another Trip
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      </section>
    </div>
  );
};

export default Booking;