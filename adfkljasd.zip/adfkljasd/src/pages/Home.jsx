import React from 'react';
import './Home.css';
import { Link } from 'react-router-dom';
import destination1 from '../assets/destination1.jpg';
import destination2 from '../assets/destination2.jpg';
import destination3 from '../assets/destination3.jpg';

const Home = () => {
    return (
        <div className="home">
            {/* Hero Section */}
            <section className="hero">
                <div className="hero-overlay">
                    <div className="hero-content">
                        <div className="floating-elements">
                            <div className="floating-element el-1">🌴</div>
                            <div className="floating-element el-2">✈️</div>
                            <div className="floating-element el-3">🏔️</div>
                            <div className="floating-element el-4">🌊</div>
                        </div>
                        <h1 className="hero-title">
                            <span className="title-word word-1">Discover</span>
                            <span className="title-word word-2">the World's</span>
                            <span className="title-word word-3">Hidden Treasures</span>
                        </h1>
                        <p className="hero-subtitle">Experience unforgettable journeys with our expert guides</p>
                        <div className="hero-buttons">
                            <button className="btn-primary magnetic">
                                <span>Explore Destinations</span>
                            </button>
                            <button className="btn-secondary magnetic">
                                <span>Book Now</span>
                            </button>
                        </div>
                        <div className="scroll-indicator">
                            <div className="scroll-arrow"></div>
                        </div>
                    </div>
                </div>
            </section>

            {/* Stats Section */}
            <section className="stats-section">
                <div className="container">
                    <div className="stats-grid">
                        <div className="stat-card" data-count="50">
                            <h3>50+</h3>
                            <p>Countries</p>
                        </div>
                        <div className="stat-card" data-count="1000">
                            <h3>1000+</h3>
                            <p>Happy Travelers</p>
                        </div>
                        <div className="stat-card" data-count="15">
                            <h3>15+</h3>
                            <p>Years Experience</p>
                        </div>
                        <div className="stat-card" data-count="24">
                            <h3>24/7</h3>
                            <p>Support</p>
                        </div>
                    </div>
                </div>
            </section>

            {/* Features Section */}
            <section className="features">
                <div className="container">
                    <h2 className="section-title">
                        <span>Why Choose Us</span>
                    </h2>
                    <div className="features-grid">
                        <div className="feature-card">
                            <div className="feature-icon-wrapper">
                                <div className="feature-icon">✈️</div>
                            </div>
                            <h3>Best Price Guarantee</h3>
                            <p>We offer the best prices without compromising on quality</p>
                        </div>
                        <div className="feature-card">
                            <div className="feature-icon-wrapper">
                                <div className="feature-icon">🛡️</div>
                            </div>
                            <h3>Safe & Secure</h3>
                            <p>Your safety and security are our top priorities</p>
                        </div>
                        <div className="feature-card">
                            <div className="feature-icon-wrapper">
                                <div className="feature-icon">🌟</div>
                            </div>
                            <h3>5-Star Experiences</h3>
                            <p>Curated experiences that exceed expectations</p>
                        </div>
                    </div>
                </div>
            </section>

           {/* Popular Destinations */}
<section className="destinations-preview">
    <div className="container">
        <h2 className="section-title">
            <span>Popular Destinations</span>
        </h2>
        <div className="destinations-grid">
            <div className="destination-card">
                <div className="popular-tag">Most Popular</div>
                <div className="rating-badge">4.8</div>
                <div className="card-image">
                    <img src={destination1} alt="Paris" />
                    <div className="card-overlay"></div>
                </div>
                <div className="destination-info">
                    <h3>Paris, France</h3>
                    <p>From $899</p>
                    <div className="location">City of Lights</div>
                    <div className="card-buttons">
                        <button className="card-btn">Explore</button>
                        <button className="card-btn secondary">Details</button>
                    </div>
                </div>
            </div>
            <div className="destination-card">
                <div className="rating-badge">4.9</div>
                <div className="card-image">
                    <img src={destination2} alt="Bali" />
                    <div className="card-overlay"></div>
                </div>
                <div className="destination-info">
                    <h3>Bali, Indonesia</h3>
                    <p>From $699</p>
                    <div className="location">Island Paradise</div>
                    <div className="card-buttons">
                        <button className="card-btn">Explore</button>
                        <Link to="/details">
      <button className="card-btn secondary">
        Details
      </button>
   </Link>
                    </div>
                </div>
            </div>
            <div className="destination-card">
                <div className="popular-tag">Trending</div>
                <div className="rating-badge">4.7</div>
                <div className="card-image">
                    <img src={destination3} alt="Tokyo" />
                    <div className="card-overlay"></div>
                </div>
                <div className="destination-info">
                    <h3>Tokyo, Japan</h3>
                    <p>From $1099</p>
                    <div className="location">Modern Metropolis</div>
                    <div className="card-buttons">
                        <button className="card-btn">Explore</button>
                        <button className="card-btn secondary">Details</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

            {/* Testimonials Section */}
            <section className="testimonials">
                <div className="container">
                    <h2 className="section-title">
                        <span>What Travelers Say</span>
                    </h2>
                    <div className="testimonials-grid">
                        <div className="testimonial-card">
                            <div className="testimonial-content">
                                <p>"Absolutely breathtaking experience! The guides were knowledgeable and the itinerary was perfect."</p>
                                <div className="testimonial-author">
                                    <div className="author-avatar">👩</div>
                                    <div className="author-info">
                                        <h4>Sarah Johnson</h4>
                                        <p>Adventure Seeker</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="testimonial-card">
                            <div className="testimonial-content">
                                <p>"Best vacation ever! Everything was perfectly organized. Can't wait to book my next trip!"</p>
                                <div className="testimonial-author">
                                    <div className="author-avatar">👨</div>
                                    <div className="author-info">
                                        <h4>Mike Chen</h4>
                                        <p>World Explorer</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    );
};

export default Home;