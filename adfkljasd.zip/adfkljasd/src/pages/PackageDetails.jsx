import React, { useState, useEffect } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { calculatePrice, createBooking } from "../api/bookings";
import "./PackageDetails.css";

const sampleData = {
  id: 1,
  title: "Pokhara Adventure Tour",
  destination: "Pokhara",
  duration: "2 Days / 1 Night",
  price: { perPerson: 120 },
  rating: 4.8,
  reviews: 42,
  image: "https://images.unsplash.com/photo-1544551763-46a013bb70d5?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
  itinerary: [
    { day: "Day 1", activity: "Drive to Pokhara + Lakeside walking + Boating" },
    { day: "Day 2", activity: "Sarangkot sunrise + Return to Kathmandu" }
  ],
  includes: [
    "Hotel stay 3⭐",
    "Breakfast included",
    "Pickup & Drop",
    "Professional guide"
  ],
  mapEmbed:
    "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3539.808231558751!2d83.952952!3d28.209583!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x399595105be0d949%3A0x63a70c3a4e570faf!2sPhewa%20Lake!5e0!3m2!1sen!2snp!4v1706203123456"
};

function PackageDetails() {
  const { id: packageId } = useParams();
  const navigate = useNavigate();

  const [pkg, setPkg] = useState(null);
  const [startDate, setStartDate] = useState("");
  const [numberOfPeople, setNumberOfPeople] = useState(1);
  const [participants, setParticipants] = useState([]); // optional detailed info
  const [contactInfo, setContactInfo] = useState({ phone: "", email: "" });
  const [pricePreview, setPricePreview] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    setPkg(sampleData);
  }, [packageId]);

  useEffect(() => {
    let mounted = true;
    async function updatePrice() {
      try {
        if (!packageId || !numberOfPeople) return;
        const data = await calculatePrice(packageId, numberOfPeople);
        if (!mounted) return;
        setPricePreview(data);
      } catch (err) {
        setPricePreview(null);
      }
    }
    updatePrice();
    return () => (mounted = false);
  }, [packageId, numberOfPeople]);

  const handleBooking = async (e) => {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      const payload = {
        packageId,
        startDate,
        numberOfPeople,
        participants, // optional
        contactInfo,
      };
      const booking = await createBooking(payload);
      // success: redirect to booking confirmation or bookings list
      navigate(`/booking/confirmation/${booking._id}`);
    } catch (err) {
      setError(err.message || "Booking failed");
    } finally {
      setLoading(false);
    }
  };

  if (!pkg) return <p>Loading...</p>;

  //  Pricing Calculation
  const pricePerPerson = pkg.price.perPerson;
  const basePrice = pricePerPerson * numberOfPeople;
  const discount = numberOfPeople >= 7 ? basePrice * 0.15 : 0; // 15% off groups ≥7
  const finalPrice = basePrice - discount;

  return (
    <section className="package-details-section">
      <div className="container">

        {/* Image + Title */}
        <div className="package-header-details">
          <img className="hero-image" src={pkg.image} alt={pkg.title} />
          <div>
            <h1>{pkg.title}</h1>
            <p className="meta-text">
              📍 {pkg.destination} • ⏱ {pkg.duration} • ⭐ {pkg.rating} ({pkg.reviews} reviews)
            </p>
          </div>
        </div>

        <div className="details-layout">
          {/*  Left Content */}
          <div className="left-content">
            
            {/* Itinerary */}
            <h2>Itinerary</h2>
            <div className="itinerary-box">
              {pkg.itinerary.map((item, index) => (
                <div key={index} className="itinerary-item">
                  <strong>{item.day}: </strong> {item.activity}
                </div>
              ))}
            </div>

            {/* Includes */}
            <h2>What's Included </h2>
            <ul className="includes-list">
              {pkg.includes.map((inc, i) => (
                <li key={i}>✔ {inc}</li>
              ))}
            </ul>

            {/* Map */}
            <h2>Location Map</h2>
            <iframe
              title="map"
              src={pkg.mapEmbed}
              className="map-iframe"
              loading="lazy"
              allowFullScreen
            ></iframe>
          </div>

          {/*  Right Sticky Sidebar */}
          <div className="right-sidebar">
            <div className="pricing-box">
              <p className="price-label">Price Per Person:</p>
              <h3>${pricePerPerson}</h3>

              {/* People Counter */}
              <div className="people-box">
                <span>People:</span>
                <div className="counter">
                  <button onClick={() => setNumberOfPeople(Math.max(1, numberOfPeople - 1))}>-</button>
                  <span>{numberOfPeople}</span>
                  <button onClick={() => setNumberOfPeople(numberOfPeople + 1)}>+</button>
                </div>
              </div>

              {/* Group Offer */}
              {numberOfPeople >= 7 && (
                <p className="discount-msg">🎉 Group Discount Applied (15% OFF!)</p>
              )}

              <div className="total-price">
                Total: <strong>${finalPrice}</strong>
              </div>

              {/* Book Now */}
              <button className="book-btn-full" onClick={handleBooking}>
                {loading ? "Booking..." : "Book Now"}
              </button>
            </div>
          </div>

        </div>

        {/* Booking Form - Optional / Conditional Rendering */}
        <form onSubmit={handleBooking} className="booking-form">
          <label>Start Date
            <input type="date" value={startDate} onChange={e => setStartDate(e.target.value)} required />
          </label>

          <label>Number of People
            <input type="number" min="1" value={numberOfPeople} onChange={e => setNumberOfPeople(parseInt(e.target.value || 1))} />
          </label>

          <label>Contact Email
            <input type="email" value={contactInfo.email} onChange={e => setContactInfo({...contactInfo, email: e.target.value})} required />
          </label>

          <label>Contact Phone
            <input value={contactInfo.phone} onChange={e => setContactInfo({...contactInfo, phone: e.target.value})} />
          </label>

          {pricePreview && (
            <div className="price-preview">
              <div>Base: {pricePreview.basePrice}</div>
              <div>Discount: {pricePreview.discount}% ({pricePreview.discountAmount})</div>
              <div>Total: {pricePreview.finalPrice}</div>
            </div>
          )}

          {error && <div className="error">{error}</div>}

          <button type="submit" disabled={loading}>
            {loading ? "Booking..." : "Book Now"}
          </button>
        </form>

      </div>
    </section>
  );
}

export default PackageDetails;
