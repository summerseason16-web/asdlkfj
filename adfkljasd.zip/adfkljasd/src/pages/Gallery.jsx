// Gallery.jsx
import React, { useState } from 'react';
import './Gallery.css';

const Gallery = () => {
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedImage, setSelectedImage] = useState(null);

  const categories = ['All', 'Nepal', 'Indonesia', 'Maldives', 'Thailand', 'Adventure', 'Cultural', 'Luxury'];

  const galleryImages = [
    {
      id: 1,
      src: "https://images.unsplash.com/photo-1544735716-2f8e3f4c3b3c?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
      category: ['Nepal', 'Cultural'],
      title: "Kathmandu Durbar Square",
      location: "Kathmandu, Nepal"
    },
    {
      id: 2,
      src: "https://images.unsplash.com/photo-1518548419970-58e3b4079ab2?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
      category: ['Indonesia', 'Cultural'],
      title: "Bali Temple",
      location: "Bali, Indonesia"
    },
    {
      id: 3,
      src: "https://images.unsplash.com/photo-1514282401047-d79a71a590e8?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
      category: ['Maldives', 'Luxury'],
      title: "Maldives Overwater Villa",
      location: "Maldives"
    },
    {
      id: 4,
      src: "https://images.unsplash.com/photo-1552465011-b4e21bf6e79a?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
      category: ['Thailand', 'Adventure'],
      title: "Thai Islands",
      location: "Thailand"
    },
    {
      id: 5,
      src: "https://images.unsplash.com/photo-1583454110551-21f2fa2ef61b?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
      category: ['Nepal', 'Adventure'],
      title: "Himalayan Trek",
      location: "Nepal Himalayas"
    },
    {
      id: 6,
      src: "https://images.unsplash.com/photo-1548013147-bdc69c49b109?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
      category: ['Nepal', 'Adventure'],
      title: "Chitwan Safari",
      location: "Chitwan, Nepal"
    },
    {
      id: 7,
      src: "https://images.unsplash.com/photo-1512453979798-5ea266f8880c?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
      category: ['Luxury'],
      title: "Dubai Skyline",
      location: "Dubai, UAE"
    },
    {
      id: 8,
      src: "https://images.unsplash.com/photo-1469474968028-56623f02e42e?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
      category: ['Adventure'],
      title: "Mountain Landscape",
      location: "Switzerland"
    },
    {
      id: 9,
      src: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
      category: ['Adventure'],
      title: "Iceland Aurora",
      location: "Iceland"
    },
    {
      id: 10,
      src: "https://images.unsplash.com/photo-1488646953014-85cb44e25828?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
      category: ['Cultural'],
      title: "Tokyo Streets",
      location: "Tokyo, Japan"
    },
    {
      id: 11,
      src: "https://images.unsplash.com/photo-1552733407-5d5c46c3bb3b?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
      category: ['Cultural'],
      title: "Paris Cityscape",
      location: "Paris, France"
    },
    {
      id: 12,
      src: "https://images.unsplash.com/photo-1464822759849-e41f5bc7c13f?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
      category: ['Adventure'],
      title: "Mountain Climbing",
      location: "Alps, Europe"
    }
  ];

  const filteredImages = selectedCategory === 'all' 
    ? galleryImages 
    : galleryImages.filter(image => image.category.includes(selectedCategory));

  const openLightbox = (image) => {
    setSelectedImage(image);
  };

  const closeLightbox = () => {
    setSelectedImage(null);
  };

  return (
    <div className="gallery-page">
      {/* Hero Section */}
      <section className="gallery-hero">
        <div className="container">
          <div className="hero-content">
            <h1 className="hero-title">Travel Gallery</h1>
            <p className="hero-subtitle">
              Explore breathtaking moments from around the world. 
              Get inspired for your next adventure through our visual journey.
            </p>
          </div>
        </div>
      </section>

      {/* Gallery Filters */}
      <section className="gallery-filters">
        <div className="container">
          <div className="filter-buttons">
            {categories.map(category => (
              <button
                key={category}
                className={`filter-btn ${selectedCategory === category ? 'active' : ''}`}
                onClick={() => setSelectedCategory(category)}
              >
                {category}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Gallery Grid */}
      <section className="gallery-section">
        <div className="container">
          <div className="gallery-grid">
            {filteredImages.map(image => (
              <div 
                key={image.id} 
                className="gallery-item"
                onClick={() => openLightbox(image)}
              >
                <div className="image-container">
                  <img src={image.src} alt={image.title} />
                  <div className="image-overlay">
                    <div className="image-info">
                      <h3 className="image-title">{image.title}</h3>
                      <p className="image-location">{image.location}</p>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Modal */}
      {selectedImage && (
        <div className="lightbox" onClick={closeLightbox}>
          <div className="lightbox-content" onClick={(e) => e.stopPropagation()}>
            <button className="lightbox-close" onClick={closeLightbox}>
              ×
            </button>
            <img src={selectedImage.src} alt={selectedImage.title} />
            <div className="lightbox-info">
              <h2>{selectedImage.title}</h2>
              <p>{selectedImage.location}</p>
              <div className="image-categories">
                {selectedImage.category.map((cat, index) => (
                  <span key={index} className="category-tag">{cat}</span>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Gallery;