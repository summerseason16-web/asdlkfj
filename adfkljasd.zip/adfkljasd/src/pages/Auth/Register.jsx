import React, { useState } from "react";
import { Container, Row, Col, Card, Form, Button } from "react-bootstrap";
import { Link, useNavigate } from "react-router-dom";
import "./Auth.css";

const Register = () => {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    password: "",
  });
  const [error, setError] = useState("");
  const navigate = useNavigate();

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    const validationErrors = validateForm();

    if (Object.keys(validationErrors).length === 0) {
      try {
        const res = await fetch("http://localhost:5000/api/auth/register", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(formData),
        });
        const data = await res.json();
        if (res.ok) {
          localStorage.setItem("userToken", data.token);
          navigate("/"); // redirect after register
        } else {
          setError(data.message || "Registration failed");
        }
      } catch (err) {
        setError("Network error");
      }
    } else {
      setError(validationErrors);
    }
  };

  const validateForm = () => {
    const errors = {};

    if (!formData.name.trim()) {
      errors.name = "Name is required";
    }

    if (!formData.email) {
      errors.email = "Email is required";
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      errors.email = "Email is invalid";
    }

    if (!formData.password) {
      errors.password = "Password is required";
    } else if (formData.password.length < 6) {
      errors.password = "Password must be at least 6 characters";
    }

    return errors;
  };

  return (
    <div className="auth-page">
      <Container fluid className="auth-container">
        <Row className="justify-content-center align-items-center min-vh-100">
          <Col xs={12} sm={8} md={6} lg={4}>
            <Card className="auth-card shadow-lg">
              <Card.Body className="p-5">
                {/* Header */}
                <div className="text-center mb-4">
                  <h2 className="auth-title">Create Account</h2>
                  <p className="text-muted">Join us and start your journey</p>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="alert alert-danger text-center mb-4">
                    {error}
                  </div>
                )}

                {/* Registration Form */}
                <Form onSubmit={handleSubmit}>
                  {/* Name Field */}
                  <Form.Group className="mb-3">
                    <Form.Label>Name</Form.Label>
                    <Form.Control
                      type="text"
                      name="name"
                      value={formData.name}
                      onChange={handleChange}
                      placeholder="Enter your name"
                      className={error.name ? "is-invalid" : ""}
                    />
                    {error.name && (
                      <Form.Control.Feedback type="invalid">
                        {error.name}
                      </Form.Control.Feedback>
                    )}
                  </Form.Group>

                  {/* Email Field */}
                  <Form.Group className="mb-3">
                    <Form.Label>Email Address</Form.Label>
                    <Form.Control
                      type="email"
                      name="email"
                      value={formData.email}
                      onChange={handleChange}
                      placeholder="Enter your email"
                      className={error.email ? "is-invalid" : ""}
                    />
                    {error.email && (
                      <Form.Control.Feedback type="invalid">
                        {error.email}
                      </Form.Control.Feedback>
                    )}
                  </Form.Group>

                  {/* Password Field */}
                  <Form.Group className="mb-4">
                    <Form.Label>Password</Form.Label>
                    <Form.Control
                      type="password"
                      name="password"
                      value={formData.password}
                      onChange={handleChange}
                      placeholder="Create a password"
                      className={error.password ? "is-invalid" : ""}
                    />
                    {error.password && (
                      <Form.Control.Feedback type="invalid">
                        {error.password}
                      </Form.Control.Feedback>
                    )}
                  </Form.Group>

                  {/* Submit Button */}
                  <Button
                    type="submit"
                    className="w-100 auth-btn mb-3"
                    size="lg"
                  >
                    Create Account
                  </Button>

                  {/* Divider */}
                  <div className="text-center mb-3">
                    <span className="text-muted">or</span>
                  </div>

                  {/* Social Registration */}
                  <div className="d-grid gap-2">
                    <Button variant="outline-secondary" className="social-btn">
                      <i className="fab fa-google me-2"></i>
                      Sign up with Google
                    </Button>
                  </div>
                </Form>

                {/* Login Link */}
                <div className="text-center mt-4">
                  <p className="text-muted">
                    Already have an account?{" "}
                    <Link
                      to="/login"
                      className="auth-link text-decoration-none"
                    >
                      Sign in here
                    </Link>
                  </p>
                </div>
              </Card.Body>
            </Card>
          </Col>
        </Row>
      </Container>
    </div>
  );
};

export default Register;
